eng1 = "The moment I opened the window, I got to know that it was not a boy but a girl. She can mimic several male actors precisely. It doesn't seem/look like somebody else's voice. When I heard her mimicry for the first time, I was speechless. Ever since she has been in the industry, I'm her fan."
hin1 = "खिड़की खोलते ही मुझे पता चल गया कि वो कोई लड़का नहीं बल्कि लड़की है। वो कई पुरूष अभिनेताओं की हूबहू नकल कर सकती है। लगता ही नहीं कि आवाज किसी और की है। जब मैंने पहली बार उसकी मिमिक्री सुनी, तो मैं पागल हो गया। जब से वो इंडस्ट्री में है, मैं उसका फैन हूं।"
eng2 = "Autonomy in academic matters does not mean that universities should be oblivious of special need. In fact, universities are set up for the satisfaction of certain felt needs of society and they have to be fully sensitive and responsive to them."
hin2 = "शिक्षा में स्वायत्ता का अर्थ यह नहीं है कि विश्विद्यालय विशिष्ट आवश्यकताओं के प्रति ध्यान ही न दें।  वस्तुतः विश्विद्यालयों की स्थापना समाज की कुछ आवश्यकताओं को पूरा करने के लिए हुई है और इन्हें इन आवश्यकताओं को पूरा करने के लिए सजग रहना चाहिए।"

sentences = {
    '1eng': eng1,
    '1hin': hin1,
    '2eng': eng2,
    '2hin': hin2,
}